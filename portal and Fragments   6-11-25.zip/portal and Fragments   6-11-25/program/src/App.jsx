import { useState } from 'react'
import Modal from './Modal';
import Fragements from './fragements';


function App() {
  const [Open,setOpen] = useState(false);
 
  return (
    <>
    
    <button onClick={()=>setOpen(true)} 
    style={{backgroundColor:"blue",
     border:"2px solid black"}}>
    Open Modal</button>
    {Open && (<Modal>
      <div style={{backgroundColor:"yellow",
         border:"2px solid black"}}>
  
        <h2><div style={{color:"red"}}>
            Hello this is a notification!!</div></h2>
          <div><button  onClick={()=>setOpen(false)} style={{backgroundColor:"green", border:"2px solid black"}}>
            Close</button>
          </div>
      </div>
    </Modal>
   
  )}
    </>
  )
}

export default App
