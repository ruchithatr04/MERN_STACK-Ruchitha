import React from 'react'

function Fragements() {

  return (
    <>
        <div>
            <div style={{backgroundColor:"red"}}>
             <h2 >Ruchitha TR</h2>
             <p>React Developer</p>
            </div>
        <>
            <div style={{backgroundColor:"blue"}}>
             <h2>Vismaya</h2>
             <p>React Developer</p>
            </div>
        </>
        <React.Fragment >
            <div style={{backgroundColor:"yellow"}}>
             <h2>Ranjitha H</h2>
             <p>React Developer</p>
            </div>
        </React.Fragment>
        </div>
    </>
  )
}

export default Fragements