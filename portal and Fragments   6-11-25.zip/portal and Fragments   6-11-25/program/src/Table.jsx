import React from 'react'

function Table() {
    const rowStyle1 ={
        backgroundColor:"red",
        color:"yellow",
    };
    const cellStyle ={
        padding: "10px",
        border: "2px solid black",
    };

    const rowStyle2 ={
        backgroundColor:"blue",
        color:"white",
    };
  return (
   <>
   
   <tr style={rowStyle1}>
    <td style={cellStyle}>Ruchitha </td>
    <td>React developer </td>
   </tr>

    <tr style={rowStyle2}>
    <td style={cellStyle}>Vismaya</td>
    <td>React developer</td>
   </tr>
   </>
  )
}

export default Table