import React from 'react'

function FirstComponent(props) {

  return (

    <div>
        <h1>First Component {props.name}</h1>

        <h2><SecondComponent phno=" : 9876543212"/></h2>

        </div>
  )
}

function SecondComponent(props1) {

  return (

    <div>Second Component {props1.phno}</div>
    
  )
}

export default FirstComponent