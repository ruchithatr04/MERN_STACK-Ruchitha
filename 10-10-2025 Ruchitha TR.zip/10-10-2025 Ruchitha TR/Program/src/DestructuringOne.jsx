import React from 'react'

function Car1({color}){
    return(
        <h1>My car is {color}!</h1>
    );
}

export default Car1