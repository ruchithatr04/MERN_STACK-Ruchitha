import React from 'react'

function Car2(props){
    const {brand,model}= props;
    return (
        <h1>I love my {brand} {model} !</h1>
    );
}

export default Car2