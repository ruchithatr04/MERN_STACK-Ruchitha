import React from 'react'

function Parent() {
  return (
    <div>
        <h1>My Two Children.</h1>
        <Son>
            <p>
                This was written in the Parent component, but displayed as part of the Son component.
            </p>
        </Son>
        <Daughter brand="Apple" model="iPhone 15">
            <p>
                This was written in the parent component, but displayed as part of the Daughter component.
            </p>
        </Daughter>
    </div>
  );
}


function Son(props) {

  return (

    <div style= {{background: "lightgreen", padding:"10px", margin:"10px"}}>

        <h2>Son :- </h2>

        <div>{props.children}</div>

    </div>

  );

}


function Daughter({brand, model, children}) {

  return (

    <div style={{background: "lightblue", padding:"10px", margin:"10px"}}>

        <h2>Daughter :- {brand  && `(${brand}, ${model})`}</h2>

        <div>{children}</div>

    </div>

  );

}
export default Parent