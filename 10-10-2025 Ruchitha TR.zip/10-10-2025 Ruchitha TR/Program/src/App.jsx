import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
import Parent from './PropsChildren'
import Check from './ConditionalRendering'
import ClassResult from './ConditionalRendering'
import Car from './Logical'
import Car1 from './Destructuringone'
import Car2 from './DestructuringTwo'
import Parent1 from './PropDrilling'

function App() {
  return (
    <div>
      <FirstComponent name=": Ruchitha TR" />

      <FirstComponent name=": Ruchitha TR" />

      <FirstComponent name=": Ruchitha TR" />

      <Fruit />
      <Fruit></Fruit>

      <Parent /> 

      {/* string value in '' */}

      <Check isresult='True'/>

      {/* boolean value in {} */}

      <ClassResult isresult={false}/>

      {/* logical && operator */}

      <Car brand="Ford"/>

      {/* props Destructuringone */}

      <Car1 color="Black"/>

      {/* props DestructuringTwo */}

      <Car2 brand="Ford" model="Mustang"/>

      {/* prop PropDrilling */}

      <Parent1 studentName="Ruchitha"/>

    </div>
  )
}

export default App