import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
import Parent from './PropsChildren'

function App() {
  return (
    <div>
      <FirstComponent name=": Ruchitha TR" />

      <FirstComponent name=": Ruchitha TR" />

      <FirstComponent name=": Ruchitha TR" />

      <Fruit />
      <Fruit></Fruit>

      <Parent /> 
    </div>
    
    
  
  )
}

export default App