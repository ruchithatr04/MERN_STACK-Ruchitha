import { useState} from "react";

function ControlledForm() {
    const [name, setName] = useState(""); //1st executs //5th executes

    const handleChange = (e)=>{           //4th executed
        setName(e.target.value);
        document.getElementById("result").innerText = e.target.value;
    };

    const handleSubmit = (e) => {         //7th executed
        e.preventDefault();
        alert(`Submitted Name: ${name}`);
    };

    return(
        <div>
            <form onSubmit={handleSubmit}>  {/*//2nd executed*/}
                <label>Enter your name:</label>
                <input type="text" value={name} onChange={handleChange}/>   {/*//3rd executed*/}
                <button type="submit">Submit</button>        {/*//6th executed*/}
            </form>
            <p id="result"></p>
        </div>
    );
}

export default ControlledForm