import React from 'react'
import HtmlForms from './HtmlForms'
import ControlledForm from './ControlledForm'
import TwoWayBinding from './TwowayBinding'
import FormValidation from './FormValidation'

function App() {
  return (
    <div>
      <HtmlForms/>
      <ControlledForm/>
      <TwoWayBinding/>
      <FormValidation/>

    </div>
  )
}




export default App