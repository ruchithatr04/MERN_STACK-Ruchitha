import React, { useState } from 'react'

function FormValidation() {
    const [email, setEmail] = useState("");
    const [error, setError] = useState("");

    const [number, setNumber] = useState("");
     const [error2, setError2] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        if(!email.includes("@")){
            setError("Please enter a valid email!");
        } else{
            setError("");
            alert(`Email Submitted: ${email}`);
        }

        if(number.length !==10 ){

        setError2("Please enter a valid number!");
        } else{
            setError2("");
            alert(`Number Submitted: ${number}`);
        };

    };

    return(
        <form onSubmit={handleSubmit}>
            <input type='email' value={email} onChange={(e) => setEmail(e.target.value)}/>
            <input type='number' value={number} onChange={(e)=> setNumber(e.target.value)}  />
            <button type='submit'>Submit</button>
            {error && <p style={{color:"red"}}>{error}</p>}
            {error2 && <p style={{color:"red"}}>{error2}</p>}
        </form>
    );
}

export default FormValidation