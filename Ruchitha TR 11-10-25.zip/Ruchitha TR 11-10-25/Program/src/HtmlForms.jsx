import React from 'react'

function HtmlForms() {
  return (
    <div>
    <form>
        <input type='email' id='user'/>
        <button>submit</button>
    </form>
    </div>
  )
}

export default HtmlForms