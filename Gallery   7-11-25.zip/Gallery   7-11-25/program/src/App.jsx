import React, { useEffect, useState } from 'react'

function App() {
  const [images, setImages] = useState([]);  //store Images
  const[loading, setLoading] = useState(true);
  const[error, setError] = useState(null);

  useEffect(()=>{
    const loadImages =async () =>{
      console.log("🔁fetching images from API...");

      try{
        const res = await fetch("https://picsum.photos/v2/list?page=2&limit=20");
        console.log("🌐 API Response Status:", res.status);

        if(!res.ok) throw new Error(`Network Response was not ok: ${res.status}`);

        const data = await res.json ();

        console.log("✅ Fetching data:", data);

        setImages(data);
      }catch(err)
      {
        console.error("❌ Error Fetching Images:", err);
        setError(err);
      }finally{
        console.log(" 🎯 Fetch Operation is Complete.");
        setLoading(false);
      }
      };

      loadImages();
  }, []);

  if(loading) return <p>Loading Photos...</p>
  if(error) return <p>Failed to Load Photos...</p>
  return (
    <div>
      <h1>Photo Gallery📸</h1>
      <div>
        {images.map((img) => (
          <div key={img.id}>
            <img src={img.download_url}
            alt={img.author}/>
          </div>
        ))}
      </div>
    </div>
  )
}

export default App