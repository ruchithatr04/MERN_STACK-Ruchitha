import React from 'react'
import { Link } from 'react-router-dom'
import NavBar from './NavLink'


function Index() {
  return (
    <div>
        <h1>This is a Index Page</h1>
        <nav>
          <Link to='/home'>HomePage || </Link>
          <Link to='/about'>AboutUs ||</Link>
          <Link to='/contact'>ContactUs</Link>
        </nav>
        <NavBar/>
    </div>
  )
}

export default Index