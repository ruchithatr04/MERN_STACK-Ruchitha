import React from 'react'
import { BrowserRouter , Routes, Route} from 'react-router-dom'
import Index from './Index'
import Home from './Home'
import About from './About'
import ContactPage from './ContactPage'
import NavBar from './NavLink'


function App() {
  return (
    <div><h1>This is a App File</h1>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Index />}/>
      <Route path='/home' element={<Home />}/>
      <Route path='/contact' element={<ContactPage />}/>
      {/* <Route path='/about' element={<About />}/>  */}
      <Route path='/about' element={<NavBar/>}/>
    </Routes>
    </BrowserRouter>
    </div>
  )
}

export default App