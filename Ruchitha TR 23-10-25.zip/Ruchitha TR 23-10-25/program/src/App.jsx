import React from 'react'
import Component1 from './ContextApi'
import Ref from './Ref'
import AccessingDom from './AccessingDom'
import Track from './Track'




function App() {
  return (
    <div>
      <Component1/>
      <Ref/>
      <AccessingDom/>
      <Track/>
      
      
      
    </div>
  )
}

export default App