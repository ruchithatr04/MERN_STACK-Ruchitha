import React from 'react'
import Component1 from './ContextApi'
import Ref from './Ref'
import AccessingDom from './AccessingDom'
import Track from './Track'
import Counter from './Reducer'
import Reducer from './Reducer2'
import WithUseMemo from './Usememo'
import Parent from './UseCallback'
import CounterApp from './CounterApp'




function App() {
  return (
    <div>
      <Component1/>
      <Ref/>
      <AccessingDom/>
      <Track/>
      <Counter/>
      <Reducer/>
      <WithUseMemo/>
      <Parent/>
      <CounterApp/>
      
      
      
    </div>
  )
}

export default App