import React from 'react'
import Hook from './Hooks'
import Counter from './Counter'
import Cleanup from './CleanUp'
import UserList from './Userslist'
import Greeting from './Css'
import Temperature from './Css'
import External from './External'
import Button from './Button'
import ProductCard from './StyledComponent'

function App() {
  return (
    <div>
       <Hook/>
      <Counter/>
       <Cleanup/> 
      {/* <UserList/> */}
      <Greeting/> 
      <Temperature/> 
      <External/>
      <Button/>
      
      <ProductCard/>

    </div>

  )
}

export default App