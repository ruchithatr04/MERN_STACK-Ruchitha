import React, {useEffect, useState } from "react";
function UserList(){
    const[users, setUsers] = useState([]);
    const[loading, setLoading]=useState(true);
    useEffect(()=>{
        async function fetchData(){
            const res = await
            fetch("https://fakestoreapi.com/products");
            const data = await res.json();
            setUsers(data);
            setLoading(false);
        }
        fetchData();
    },[]);
    return(
        <div>
            <h2>Users List</h2>
            {loading ?(
                <p>Loading...</p>
            ) : (
                <ul>
                    {users.map((users)=>(
                        <div>
                            <li key={users.id}>{users.name} || {users.title} || 
                                {users.price} || {users.description}</li>
                            <img src={users.image } ></img>
                        </div>
                        
                    ))}
                </ul>
            )}
        </div>
    );
}
export default UserList