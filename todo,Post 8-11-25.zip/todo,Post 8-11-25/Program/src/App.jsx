import React from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
// import Todo from './Todo'
import Posts from './Post'

const client = new QueryClient();

function App() {
  return (
   <QueryClientProvider client={client}>
     <div>
      <Posts/>


      {/* <Todo/> */}
    </div>
   </QueryClientProvider>

   
  )
}

export default App