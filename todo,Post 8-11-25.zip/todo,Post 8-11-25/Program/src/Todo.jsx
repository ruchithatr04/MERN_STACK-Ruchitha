import axios from "axios";
import React, { useEffect, useState } from "react";

function Todo() {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [limit, setLimit] = useState(10);

  useEffect(() => {
    setLoading(true);
    axios
      .get("https://jsonplaceholder.typicode.com/todos/")
      .then((res) => {
        setTodos(res.data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err);
        setLoading(false);
      });
  }, []);

  const handleLoadMore = () =>{
    setLimit((prevLimit)=> prevLimit +5)
  }

  if (error)
    return (
      <p style={{ color: "red", textAlign: "center", fontWeight: "bold" }}>
        ❌ Error fetching todos
      </p>
    );

  if (loading)
    return (
      <p style={{ color: "#6b46c1", textAlign: "center", fontWeight: "bold" }}>
        ⌛ Loading...
      </p>
    );

  return (
    <div
      style={{
        maxWidth: "700px",
        margin: "40px auto",
        backgroundColor: "#f8fafc",
        padding: "25px",
        borderRadius: "15px",
        boxShadow: "0 6px 15px rgba(0, 0, 0, 0.1)",
        fontFamily: "Poppins, sans-serif",
      }}
    >
      <h3
        style={{
          textAlign: "center",
          color: "#2b6cb0",
          fontSize: "1.8rem",
          marginBottom: "25px",
        }}
      >
        📋 Todo List
      </h3>

      {todos.slice(0, limit).map((todo) => (
        <div
          key={todo.id}
          style={{
            backgroundColor: "#f1def1ff",
            marginBottom: "15px",
            padding: "15px 20px",
            borderRadius: "12px",
            borderLeft: "6px solid #8e1295ff",
            boxShadow: "0 3px 8px rgba(0, 0, 0, 0.1)",
            transition: "transform 0.2s ease",
          }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.transform = "translateY(-3px)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.transform = "translateY(0)")
          }
        >
          <h4
            style={{
              color: "#333",
              fontSize: "1.1rem",
              marginBottom: "8px",
              textTransform: "capitalize",
            }}
          >
            {todo.title}
          </h4>
          <p
            style={{
              fontWeight: "500",
              color: todo.completed ? "#2f855a" : "#c53030",
            }}
          >
            Status: {todo.completed ? "✅ Completed" : "❌ Pending"}
          </p>
        </div>
      ))}
      {limit < todos.length && (
        <button style={{backgroundColor:"blue", color:"white", border:"3px solid black",transition: "transform 0.2s ease"}}
         onClick={handleLoadMore}>Load more</button>
      )}
    </div>
  );
}

export default Todo;